<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Projet Site - Page Membre</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Start your project here-->
  <div style="height: 100vh">
  <!--Navbar -->
  <nav class="mb-1 navbar navbar-expand-lg navbar-dark default-color">
    <a class="navbar-brand" href="index.php">Jobstart</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Accueil
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="membre.php">Gestion du Personnel</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stat.php">Statistique</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./ajout.php">Ajouter</a>
        </li>

      </ul>
      <ul class="navbar-nav ml-auto nav-flex-icons">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-default"
            aria-labelledby="navbarDropdownMenuLink-333">
            <a class="dropdown-item" href="#">Information</a>
            <a class="dropdown-item" href="#">Se déconnecter</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <!--/.Navbar -->
  <h1 class="titre-page">Gestion du Personnel</h1>
  <!-- Debut liste personnel-->
  <div class="container animated bounceIn">
    <div class="row">
        <table class="table table-modif">
            <thead>
            <tr>
                <th scope="col">Nom</th>
                <th scope="col">Prenom</th>
                <th scope="col">Fonction</th>
                <th scope="col">Absences</th>
                <th scope="col">Voir plus</th>
            </tr>
            </thead>
            <tbody class="tbody-modif">
              <?php
              include('./inclusion.inc/fcts_connect.php');
                $bdd=connect();
                $reponse = $bdd->query('SELECT nom,prenoms,emploi,id,nb_absence FROM personnel');
                while($donnees = $reponse->fetch()){;
                  if ($donnees['nb_absence']<=2){
                    echo('<tr>
                        <th>'.$donnees['nom'].'</th>
                        <th>'.$donnees['prenoms'].'</th>
                        <th>'.$donnees['emploi'].'</th>
                        <th style="color:green;">'.$donnees['nb_absence'].'</th>
                        <th><a href="recap.php?iddem='.$donnees['id'].'"><button class="btn btn-info">En savoir plus</button></a></th>
                    </tr>');
                  }
                  elseif ($donnees['nb_absence']>5){
                    echo('<tr>
                        <th>'.$donnees['nom'].'</th>
                        <th>'.$donnees['prenoms'].'</th>
                        <th>'.$donnees['emploi'].'</th>
                        <th style="color:red;">'.$donnees['nb_absence'].'</th>
                        <th><a href="recap.php?iddem='.$donnees['id'].'"><button class="btn btn-info">En savoir plus</button></a></th>
                    </tr>');
                  }
                  else{
                    echo('<tr>
                        <th>'.$donnees['nom'].'</th>
                        <th>'.$donnees['prenoms'].'</th>
                        <th>'.$donnees['emploi'].'</th>
                        <th style="color:orange;">'.$donnees['nb_absence'].'</th>
                        <th><a href="recap.php?iddem='.$donnees['id'].'"><button class="btn btn-info">En savoir plus</button></a></th>
                    </tr>');
                  };

              	}
                ?>
            </tbody>
        </table>
    </div>
  </div>
  <!-- Fin liste personnel-->
  </div>

  <!-- Modal -->

  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>

</body>
</html>
