<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Projet Site</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Start your project here-->
  <div style="height: 100vh">
  <!--Navbar -->
  <nav class="mb-1 navbar navbar-expand-lg navbar-dark default-color">
    <a class="navbar-brand" href="index.php">Jobstart</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="/index.php">Accueil
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="membre.php">Gestion du Personnel</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stat.php">Statistique</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ajout.php">Ajouter</a>
        </li>

      </ul>
      <ul class="navbar-nav ml-auto nav-flex-icons">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-default"
            aria-labelledby="navbarDropdownMenuLink-333">
            <a class="dropdown-item" href="#">Information</a>
            <a class="dropdown-item" href="#">Se déconnecter</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <!--/.Navbar -->
  <?php
  include('./inclusion.inc/fcts_connect.php');
  $bdd=connect();
  $numdem=$_GET['iddem'];
  $rep = $bdd->query('SELECT nom,prenoms
    FROM personnel
    WHERE personnel.id='.$numdem.'');
  while($donnees = $rep->fetch()){;
    ?>

  <h2 style="text-align:center;margin: 50px;">Rechercher un profil type </h2>
  <p style="text-align:center;font-size:20px;">Le profil correspondant le plus a <?=  $donnees['nom'].'  '.$donnees['prenoms'];?> est :<?php
  $rep = $bdd->query('SELECT nom,prenoms
      FROM personnel
      WHERE personnel.id=9');
    while($lignes = $rep->fetch()){;
echo(' '.$lignes['nom']. ' '.$lignes['prenoms'].'');
};
      ?> avec<?php
    $rep = $bdd->query('SELECT count(libelle) as nb from (SELECT libelle
                  FROM competences
                  inner join competencespersonnels on competences.id=competencespersonnels.fk_id_competence
                  inner join personnel on competencespersonnels.fk_id_personnel =personnel.id
                  WHERE personnel.id=8
				  INTERSECT
SELECT libelle
                  FROM competences
                  inner join competencespersonnels on competences.id=competencespersonnels.fk_id_competence
                  inner join personnel on competencespersonnels.fk_id_personnel =personnel.id
                  WHERE personnel.id=9) as Ab');
    while($ligne = $rep->fetch()){;
      echo(' '.$ligne['nb']. ' compétence(s) commune(s)');
    };  ?>     </p>
  <div class="container">
  <div class="row">
    <div class="col-md-12" style="text-align:center;">
        <button class="btn btn-md btn-danger"><a style="text-decoration:none;color: white;" href="recap.php?iddem=9">CONSULTER LA FICHE</a></button>
        <button class="btn btn-md btn-info">RETOUR A L'ACCUEIL</button>
    </div>
  </div>
  </div>
  </div>
<?php
}
 ?>
  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
</body>
</html>
