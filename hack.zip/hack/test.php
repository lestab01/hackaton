<?php
session_start();
include('./inclusion.inc/fcts_connect.php');
include('./inclusion.inc/fonction_date.inc');
$bdd=connect();
$numdem=$_GET['iddem'];
$reponse = $bdd->query('SELECT nom,prenoms,emploi FROM personnels WHERE id='.$numdem.'');

while($donnees = $reponse->fetch()){;
  echo('il sagit de '.$donnees['nom'].''.$donnees['prenoms'].'employe dans'.$donnees['emploi']);

}
?>
 </body>
</html>
