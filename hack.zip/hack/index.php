<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Projet Site</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Start your project here-->
  <div style="height: 100vh">
  <!--Navbar -->
  <nav class="mb-1 navbar navbar-expand-lg navbar-dark default-color">
    <a class="navbar-brand" href="index.php">Jobstart</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Accueil
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="membre.php">Gestion du Personnel</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stat.php">Statistique</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="ajout.php">Ajouter</a>
        </li>

      </ul>
      <ul class="navbar-nav ml-auto nav-flex-icons">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-default"
            aria-labelledby="navbarDropdownMenuLink-333">
            <a class="dropdown-item" href="#">Information</a>
            <a class="dropdown-item" href="#">Se déconnecter</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
  <!--/.Navbar -->
  <h2 style="text-align:center;margin: 50px;">Prochain evenement important </h2>
  <div class="container container-modif-danger">
    <div class="row">
      <div class="col-md-1">
      <i class="fas fa-exclamation-triangle fa-3x"></i>
      </div>
      <div class="col-md-11">
        <p><span style="font-weight:bold;">28-12-2019 : </span>Réunion professionnelle de DUMONT Bernard</p>
      </div>
    </div>
  </div>

  <div class="container container-modif-danger">
    <div class="row">
      <div class="col-md-12">
        <p><span style="font-weight:bold;">05-01-2020 : </span> Visite médicale Permis poids lourds ROY Louis</p>
      </div>
    </div>
  </div>

  <div class="container container-modif-warning">
    <div class="row">
      <div class="col-md-12">
        <p><span style="font-weight:bold;">25-06-2020 : </span> Entretien individuel de MARTIN Eliane</p>
      </div>
    </div>
  </div>
  <div class="container container-modif-success">
    <div class="row">
      <div class="col-md-12">
        <p><span style="font-weight:bold;">14-01-2021 : </span> Réunion professionnelle de ROY Louis</p>
      </div>
    </div>
  </div>


  </div>
  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
</body>
</html>
