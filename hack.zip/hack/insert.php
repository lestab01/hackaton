<?php
session_start();
$ab=0;
$avert=0;
$abi=0;
$ctrt=1;
include('./inclusion.inc/fcts_connect.php');
$bdd=connect();
$req = $bdd->prepare('INSERT INTO personnel(nom,prenoms,adresse,ville,code_postale,nationalité,date_naissance,sexe,qualification,date_entrée,date_retraite,salaire_brut_annuel_2013,salaire_brut_annuel_2019,contrat,emploi,service,nb_absence,nb_ab_injust,nb_avert)
VALUES (:nom, :prenoms ,:adresse, :ville, :codepostale,:natio, :datenaiss,:sexe,:qualif, :daterentree, :dateretraite,:salaire2013,:salaire2019,:contrt,:emploi,:serv,:ab,:abi,:avert)');
$req->execute([
  ':prenoms'=>$_POST['prenom'],
  ':nom'=>$_POST['nom'],
  ':adresse'=>$_POST['adresse'],
  ':ville'=>$_POST['ville'],
  ':codepostale'=>$_POST['codepostale'],
  ':natio'=>$_POST['natio'],
  ':sexe'=>$_POST['sexe'],
  ':datenaiss'=>$_POST['datenaiss'],
  ':qualif'=>$_POST['qualif'],
  ':daterentree'=>$_POST['datent'],
  ':dateretraite'=>$_POST['datere'],
  ':emploi'=>$_POST['emploi'],
  ':serv'=>$_POST['serv'],
  ':ab'=>$ab,
  ':abi'=>$abi,
  ':contrt'=>$ctrt,
  ':salaire2013'=>$_POST['salaire2013'],
  ':salaire2019'=>$_POST['salaire2019'],
  ':avert'=>$avert]);




header('Location: membre.php');
?>
