<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Projet Site</title>
  <!-- MDB icon -->
  <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <!-- Start your project here-->
  <div style="height: 100vh">
  <!--Navbar -->
  <nav class="mb-1 navbar navbar-expand-lg navbar-dark default-color">
    <a class="navbar-brand" href="index.php">Jobstart</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
      aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Accueil
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="membre.php">Gestion du Personnel</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="stat.php">Statistique</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./ajout.php">Ajouter</a>
        </li>

      </ul>
      <ul class="navbar-nav ml-auto nav-flex-icons">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-user"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right dropdown-default"
            aria-labelledby="navbarDropdownMenuLink-333">
            <a class="dropdown-item" href="#">Information</a>
            <a class="dropdown-item" href="#">Se déconnecter</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
    <!--/.Navbar -->

    <?php
    include('./inclusion.inc/fcts_connect.php');
    $bdd=connect();
    $numdem=$_GET['iddem'];
    $rep = $bdd->query('SELECT personnel.id,nom,prenoms,date_naissance,adresse,code_postale,ville,nationalité,sexe,emploi,date_entrée,date_retraite,contrat.libelle as contrt,services.libelle as serv,nb_absence,nb_ab_injust,nb_avert
      FROM personnel
      inner join contrat on personnel.contrat=contrat.id
      inner join services on personnel.service =services.id
      WHERE personnel.id='.$numdem.'');
    while($donnees = $rep->fetch()){;

      ?>
  <h1 style="text-align:center;margin: 50px;">Récapitulatif</h1>
  <a href="chercher.php?iddem=<?= $donnees['id'];?>"<bouton class="btn btn-md btn-danger" style="display:block;margin: 0 auto;">Rechercher une personne similaire</button></a>
<br/>
  <div class="container container-modif">
      <div class="row">
          <div class="col-md-4">
              <p>Nom :<?php echo($donnees['nom']) ?></p>
          </div>
          <div class="col-md-4">
            <p>Prénom :<?php echo($donnees['prenoms']) ?></p>
          </div>
          <div class="col-md-4">
            <p>Date de naissance :<?php echo($donnees['date_naissance']) ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col-md-6">
              <p>Adresse :<?php echo($donnees['adresse'].'  '.$donnees['code_postale'].'  '.$donnees['ville']) ?></p>
          </div>
          <div class="col-md-6">
              <p>Nationalité :<?php echo($donnees['nationalité']) ?></p>
          </div>
      </div>
      <div class="row">
        <div class="col-md-4">
            <p>Nationalité :</p>
        </div>
        <div class="col-md-4">
            <p>Sexe :<?php echo($donnees['sexe']) ?> </p>
        </div>
        <div class="col-md-4">
            <p>Service :<?php echo($donnees['serv']) ?> </p>
        </div>
      </div>
      <div class="row">
          <div class="col-md-3">
              <p>Emploi:<?php echo($donnees['emploi']) ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col-md-6">
              <p>Date d'entrée :<?php echo($donnees['date_entrée']) ?></p>
          </div>
          <div class="col-md-6">
              <p>Date retraite :<?php echo($donnees['date_retraite']) ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col-md-6">
              <p>Type de contrat :<?php echo($donnees['contrt']) ?></p>
          </div>
      </div>
      <div class="row">
          <div class="col-md-2">
              <p>Les competences : </p>
          </div>
          <div class="col-md-6">
              <ul>
                <?php
                $numde=$_GET['iddem'];
                $rep = $bdd->query('SELECT libelle,competencespersonnels.pourcentacquis as pourcent
                  FROM competences
                  inner join competencespersonnels on competences.id=competencespersonnels.fk_id_competence
                  inner join personnel on competencespersonnels.fk_id_personnel =personnel.id
                  WHERE personnel.id='.$numde.'');
                while($ligne = $rep->fetch()){;
                  if ($ligne['pourcent']>=75){
                    echo('<li class="text-success" >'.$ligne['libelle'].'</li>');
                  }
                  elseif ($ligne['pourcent']<25){
                    echo('<li class="text-danger">'.$ligne['libelle'].'</li>');
                  }
                  else{
                    echo('<li class="text-warning">'.$ligne['libelle'].'</li>');
                  };

            };
                  ?>
              </ul>
          </div>
      </div>
      <div class="row">
        <div class="col-md-6">
            <button class="btn btn-lg btn-info">Modifier</button>
            <a class="btn btn-lg btn-danger" href="supp.php?iddem=<?= $donnees['id'];?> ">Supprimer</a>
        </div>
    </div>
    </div>
    <br />
    <h2 style="text-align:center;margin: 10px;">Informations / Absences</h2>
    <div class="container container-modif-danger">
      <div class="row">

        <div class="col-md-12">
          <p style="font-weight: bold;">Nombres de jours d'absences :<?php echo(' '. $donnees['nb_absence']) ?>  dont <?php echo($donnees['nb_ab_injust']) ?> injustifiés</p>
        </div>
        <div class="col-md-12">
          <p style="font-weight: bold;">Nombres de retards :<?php echo(' '. $donnees['nb_absence']) ?> </p>
        </div>
        <div class="col-md-12">
         <p style="font-weight: bold;">Nombres d'avertissements : <?php echo(' '. $donnees['nb_avert']) ?></p>
        </div>
        <div class="col-md-3">
          <p>Notes:</p>
        </div>
        <div class="col-md-9">
          <p><span style="font-weight:bold;">17-12-2019 : </span>Quam ob rem id primum videamus, si placet, quatenus amor in amicitia progredi debeat. Numne, si Coriolanus habuit amicos, ferre contra patriam arma illi cumaa.</p>
        </div>
        <button class="btn btn-sm btn-danger"id="voir">Laisser une note</button>
      </div>
    </div>
    <div class="container container-modif-danger" id="view">
          <div class="row">
            <div class="col-md-12">
              <p style="font-weight: bold;">Rajouter</p>
            </div>
           <div class="col-md-6">
                <!-- Material input -->
                <div class="md-form form-group">
                  <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="entier">
                  <label for="inputDateReunion">Nombre d'absences justifiées</label>
                </div>
                <div class="md-form form-group">
                  <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="entier">
                  <label for="inputDateReunion">Nombre d'absences injustifiées</label>
                </div>
                <div class="md-form form-group">
                  <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="entier">
                  <label for="inputDateReunion">Nombre de retard </label>
                </div>
                <div class="md-form form-group">
                  <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="entier">
                  <label for="inputDateReunion">Nombre d'avertissements</label>
                </div>
              </div>
            <div class="col-md-12">
              <div class="md-form">
                <textarea type="text-area" id="form7" class="md-textarea form-control" mdbInput></textarea>
                <label for="form7">Raisons de l'avertissement</label>
              </div>
            </div>
          </div>
        </div>
    <h2 style="text-align:center;margin: 10px;">Information Entretien</h2>
   <div class="container container-modif">
     <div class="row">
       <div class="col-md-3">
         <p>Résumé du dernier entretien:</p>
       </div>
       <div class="col-md-9">
         <p><span style="font-weight:bold;">17-12-2019 : </span>Ras, etat de sante:ok /Professionnelle</p>
       </div>
       <button class="btn btn-sm btn-info"id="voir_re">Laisser une note</button>
       <button class="btn btn-sm btn-info" id="voir_reu">Prévoir</button>
     </div>
   </div>
   <div class="container container-modif" id="viewinfo">
     <div class="row">
       <div class="col-md-12">
         <p style="font-weight: bold;">Date du prochain entretien</p>
       </div>
      <div class="col-md-6">
           <!-- Material input -->
           <div class="md-form form-group">
             <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="23-12-2000">
             <label for="inputDateReunion">Date de l'entretien</label>
           </div>
         </div>
         <div class="form-row">
           <div class="col-md-6">
             <div class="custom-control custom-radio">
             <input type="radio" class="custom-control-input" id="contrat1" value="1"name="defaultExampleRadios">
             <label class="custom-control-label" for="contrat1">Professionnelle</label>
         </div>
           <div class="custom-control custom-radio">
             <input type="radio" class="custom-control-input" id="contrat2" value="2" name="defaultExampleRadios" checked>
             <label class="custom-control-label" for="contrat2">Individuelle</label>
           </div>
         </div>
         </div>
       <div class="col-md-12">
         <div class="md-form">
           <textarea type="text" id="form7" class="md-textarea form-control" mdbInput></textarea>
           <label for="form7">Titre de l'entretien</label>
         </div>
       </div>
     </div>
   </div>
  <div class="container container-modif" id="viewinf">
        <div class="row">
          <div class="col-md-12">
            <p style="font-weight: bold;">Date du prochain entretien</p>
          </div>
         <div class="col-md-6">
              <!-- Material input -->
              <div class="md-form form-group">
                <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="23-12-2000">
                <label for="inputDateReunion">Date de l'entretien</label>
              </div>
            </div>
          <div class="col-md-12">
            <div class="md-form">
              <textarea type="text-area" id="form7" class="md-textarea form-control" mdbInput></textarea>
              <label for="form7">Résumé de l'entretien</label>
            </div>
          </div>
        </div>
      </div>
    <h2 style="text-align:center;margin: 20px;">Information Complémentaire</h2>
  <div class="container container-modif-warning">
    <div class="row">
      <div class="col-md-12">
       <p style="font-weight: bold;">Mobilité :  Oui </p>
      </div>
      <div class="col-md-12">
        <p style="font-weight: bold;">Autonomie : Oui </p>
      </div>
      <div class="col-md-12">
        <p style="font-weight: bold;">Permis : B, C1,C,CE </p>
      </div>
      <button class="btn btn-sm btn-danger" id="voir_r">Prévoir</button>
    </div>
  </div>
 <div class="container container-modif-warning" id="viewin">
       <div class="row">
         <div class="col-md-12">
           <p style="font-weight: bold;">Date de la prochaine échéance</p>
         </div>
        <div class="col-md-6">
             <!-- Material input -->
             <div class="md-form form-group">
               <input type="text" class="form-control" id="inputDateReunion" name="datereunion"placeholder="12-23-2000">
               <label for="inputDateReunion">Date</label>
             </div>
           </div>
         <div class="col-md-12">
           <div class="md-form">
             <textarea type="text-area" id="form7" class="md-textarea form-control" mdbInput></textarea>
             <label for="form7">Titre</label>
           </div>
         </div>
       </div>
     </div>



  <!-- End your project here-->

  <!-- jQuery -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
  <?php
}
 ?>
 <script>
 $(document).ready(function(){
   $('#viewinfo').hide();
   $('#voir_reu').on('click',function(){
     $('#viewinfo').slideToggle(500);
   });
   $('#viewin').hide();
   $('#voir_r').on('click',function(){
     $('#viewin').slideToggle(500);
   });
   $('#viewinf').hide();
   $('#voir_re').on('click',function(){
     $('#viewinf').slideToggle(500);
   });
   $('#view').hide();
   $('#voir').on('click',function(){
     $('#view').slideToggle(500);
   });
 });

 </script>
</body>
</html>
