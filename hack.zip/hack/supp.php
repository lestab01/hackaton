<?php
session_start();
$id=intval($_GET['iddem']);
include('./inclusion.inc/fcts_connect.php');
$bdd=connect();
$req = $bdd->prepare('Delete from personnel where id=:id');
$req->execute([
  ':id'=>$id
]);



header('Location: membre.php');
?>
