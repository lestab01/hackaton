<?php
    function connect(){
      $bdd = new PDO('pgsql:host=localhost;dbname=hackathon1', 'postgres', 'toulouse');
      $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      return($bdd);
    }
?>
